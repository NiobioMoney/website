1) wallet
Windows:   simplewallet --config-file configs/niobio.conf
Linux/Mac:   ./simplewallet --config-file configs/niobio.conf
-- some erros, because you dont run step 2 yet --
-- see your wallet address --
-- type help ---

2) daemon (sync blockchain)
Windows:   forknoted --config-file configs/niobio.conf
Linux/Mac:   ./forknoted --config-file configs/niobio.conf
-- type help ---

3) miner
Windows:   miner --daemon-host 127.0.0.1 --daemon-rpc-port 8314 --address your_wallet_address
Linux/Mac:   ./miner --daemon-host 127.0.0.1 --daemon-rpc-port 8314 --address your_wallet_address
Example: miner --daemon-host 127.0.0.1 --daemon-rpc-port 8314 --address NEUgftLSYimfuFe49LsmNeFUTkaewt5Ucf1fotjv8M71JxtB2KFEJc8MeRW8yPLpCUPzRuwCvoxDtPeCxJ5Cy1BrVHeJ7k2
-- miner dont show returns, but wallet does. keep wallet open. about every 2 minutes someone mine  --
-- type balance --
-- type help --

-------------------------------
forknoted --help
simplewallet --help
miner --help

-------------------------------
problems:
- disable firewall
- run as administrador
- use ports 8313, 8314